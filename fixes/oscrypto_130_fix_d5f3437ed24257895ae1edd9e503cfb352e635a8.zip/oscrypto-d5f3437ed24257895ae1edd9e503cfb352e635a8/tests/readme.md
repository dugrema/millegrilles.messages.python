# oscrypto_tests

Run the test suite via:

```bash
python -m oscrypto_tests
```

Full documentation a <https://github.com/wbond/oscrypto#readme>.
